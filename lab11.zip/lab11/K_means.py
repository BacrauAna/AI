import random
class K_means:
    def __init__(self,nr_clust):
        self.__centr=[]
        self.__nr_clust=nr_clust

    def generateCentr(self,input):
        l=[]
        i=0
        while i<self.__nr_clust:
            print("len inp",len(input))
            x=random(len(input))
            if not x in l:
                l.append(x)
                i+=1
        for i in l:
            self.__centr.append(input[l[i]])

    def calculSum(self,a,b):
        sum=0
        for i in range(len(a)):
            sum+=(a[i]-b[i])**2
        return sum**0.5

    def findBest(self, input):
        l=[]
        cop=self.__centr[:]

        while cop!=self.__centr:
            cop=self.__centr[:]
            for i in range(len(input)):
                min=self.calculSum(input[i],self.__centr[0])
                poz_min=-1
                poz=0
                while poz<len(self.__cent):
                    val=self.calculSum(input[i],self.__centr[poz])
                    if val<=min:
                        poz_min=poz
                        min=val
                    poz+=1
                l[poz_min].append(i)
            self.refreshCentr(l, input)





    def fit(self,input):
        self.generateCentr(input)
        self.findBest(input)

    def refreshCentr(self, l, input):

        for i in range(len(l)):
            newCentr=[]

            for k in range(l[0][0]):
               numarator = sum(input[l[i][j]][k] for j in range(len(l[i])))
               numitor = len(l[i])# numitor 0???
               newCentr[k].append(numarator/numitor)
            self.__centr[i]=newCentr


    def predict(self,test):
        l=[]
        for t in test:
            poz_min=0
            sum_min=self.calculSum(t,self.__centr[0])
            for i in range(len(self.__centr)):
                suma=self.calculSum(t,self.__centr[0])
                if suma<=sum_min:
                    sum_min=suma
                    poz_min=i
            l.append(poz_min)
        return l


