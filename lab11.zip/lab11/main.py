import csv
import os
import random

def nrTeste(matrice,outputs):
    import numpy as np

    # np.random.seed(5)
    matriceTeste=[]
    outputsTeste=[]
    nrT=0.2*len(matrice)

    for _ in range(int(nrT)):
        ra=random.randrange(len(matrice)-1)
        #print(ra)
        matriceTeste.append(matrice[ra])
        outputsTeste.append(outputs[ra])
        matrice.pop(ra)
        outputs.pop(ra)
    return matriceTeste,outputsTeste


def loadData(fileName):
    data = []
    outputs=[]
    with open(fileName) as file:
        reader=file.readlines()

        for row in reader:
            l=row.split(",")
            lable=l[-1][0:-1]
            data.append(l[:-1])
            outputs.append(lable)

    print(data)
    print(outputs)
    return data,outputs

input,output=loadData("iris.data")
labelNames = list(set(output))

inpTest,outTest=nrTeste(input,output)



print(labelNames)



    from sklearn.cluster import KMeans

unsupervisedClassifier = KMeans(n_clusters=3, random_state=0)
unsupervisedClassifier.fit(input)
computedTestIndexes = unsupervisedClassifier.predict(inpTest)
computedTestOutputs = [labelNames[value] for value in computedTestIndexes]

print("TOOL")
from sklearn.metrics import accuracy_score
print("acc: ", accuracy_score(outTest, computedTestOutputs))

# from K_means import *
#
# unsupervisedClassifier = K_means(2)
# unsupervisedClassifier.fit(input)
# computedTestIndexes = unsupervisedClassifier.predict(inpTest)
# computedTestOutputs = [labelNames[value] for value in computedTestIndexes]
#
# print("Manual")
# from sklearn.metrics import accuracy_score
# print("acc: ", accuracy_score(outTest, computedTestOutputs))