from sklearn.linear_model import LogisticRegression
import random

class MySGDRegression:
    def __init__(self):
        #self.intercept_ = 0.0
        self.coef_ = []

    # simple stochastic GD
    def fit(self, x, y, learningRate = 0.001, noEpochs = 1000):
        print(x)
        print("cevax")
        print(y)
        print("cevay")
        self.coef_ = [0.0 for _ in range(len(x[0]) + 1)]    #beta or w coefficients y = w0 + w1 * x1 + w2 * x2 + ...
        # self.coef_ = [random.random() for _ in range(len(x[0]) + 1)]    #beta or w coefficients
        for epoch in range(noEpochs):
            # TBA: shuffle the trainind examples in order to prevent cycles
            error=[0 for _ in range(len(x[0])+1)]
            for i in range(len(x)): # for each sample from the training data
                ycomputed = self.eval(x[i])     # estimate the output
                crtError = ycomputed - y[i]     # compute the error for the current sample
                for j in range(0, len(x[0])):
                    error[j]+=crtError*x[i][j]
                error[len(x[0])]+=crtError
            # print("err ",error)
            # print("sum err", sum(error))
            # print("len err", len(error))

            # print(self.coef_)
            for j in range(0, len(x[0])):   # update the coefficients
                self.coef_[j] = self.coef_[j] - learningRate * error[j]/len(x)
            self.coef_[len(x[0])] = self.coef_[len(x[0])] - learningRate * error[len(x[0])]/len(x)
            # print("crtError ",crtError)
            print("Epoca:",epoch," coef: ",self.coef_)


    def eval(self, xi):
        yi = self.coef_[-1]
        for j in range(len(xi)):
            yi += self.coef_[j] * xi[j]
        return yi

    def predict(self, x):
        yComputed = [self.eval(xi) for xi in x]
        return yComputed