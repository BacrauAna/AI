import csv
import os
import random

def creareMatrice(inputsGrabLib,inputsProdBrut):
    matrix=[]
    for i in range(len(inputsProdBrut)):
        matrix.append([inputsProdBrut[i],inputsGrabLib[i]])
    return matrix



def loadData(fileName, inputVariaProdIntBrut,inputVariableGradLib, outputVariabName):
    data = []
    dataNames = []
    with open(fileName) as csv_file:
        csv_reader = csv.reader(csv_file, delimiter=',')
        line_count = 0
        for row in csv_reader:
            if line_count == 0:
                dataNames = row
            else:
                data.append(row)
            line_count += 1
    selectedVariableGradLib = dataNames.index(inputVariableGradLib)
    inputsGradLib = [float(data[i][selectedVariableGradLib]) for i in range(len(data))]

    selectedVariableProdBrut = dataNames.index(inputVariaProdIntBrut)
    inputsProdBrut = [float(data[i][selectedVariableProdBrut]) for i in range(len(data))]

    selectedOutput = dataNames.index(outputVariabName)
    outputs = [float(data[i][selectedOutput]) for i in range(len(data))]

    matrice=creareMatrice(inputsProdBrut,inputsGradLib)
    return matrice, outputs

def nrTeste(matrice,outputs):
    matriceTeste=[]
    outputsTeste=[]
    nrT=0.2*len(matrice)

    for _ in range(int(nrT)):
        ra=random.randrange(len(matrice)-1)
        #print(ra)
        matriceTeste.append(matrice[ra])
        outputsTeste.append(outputs[ra])
        matrice.pop(ra)
        outputs.pop(ra)
    return matriceTeste,outputsTeste




def citire():
    crtDir = os.getcwd()
    filePath = os.path.join( 'C:\\Users\\punga\\Downloads\\2017.csv')
    return loadData(filePath, 'Economy..GDP.per.Capita.','Freedom', 'Happiness.Score')
# inputsProdBrut,inputsGrabLib, outputs = loadData(filePath, 'Economy..GDP.per.Capita.','Freedom', 'Happiness.Score')
# print('input produs brut: lungime:',len(inputsProdBrut),' valori: ', inputsProdBrut)
# print('input grad libertate lungime:',len(inputsGrabLib),' valori: ', inputsGrabLib)
# print('out: lungime:',len(outputs),' valori: ', outputs)
