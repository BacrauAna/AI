import numpy as np
from regresion import MySGDRegression

from citireFisier import *
import matplotlib.pyplot as plt

def normalizOut(input):
    medie=sum(input)/len(input)
    devStandard=(1/len(input)*sum([(inp-medie)**2 for inp in input]))**0.5
    normVal=[(inp-medie)/devStandard for inp in input]
    return normVal

def normalizareData(inputAntr,inputTest):
    medie = sum(inputAntr) / len(inputAntr)
    devStandard = (1 / len(inputAntr) * sum([(inp - medie) ** 2 for inp in inputAntr])) ** 0.5
    normValAntr = [(inp - medie) / devStandard for inp in inputAntr]
    normValTest = [(inp - medie) / devStandard for inp in inputTest]
    return normValAntr,normValTest

def normMatrix(matriceAntr,matriceTest):
    prodAntr=[matriceAntr[i][0] for i in range(len(matriceAntr))]
    libAntr=[matriceAntr[i][1] for i in range(len(matriceAntr))]
    prodTest = [matriceTest[i][0] for i in range(len(matriceTest))]
    libTest = [matriceTest[i][1] for i in range(len(matriceTest))]
    normProdAntr,normProdTest=normalizareData(prodAntr,prodTest)
    normLibAntr,normLibTest=normalizareData(libAntr,libTest)
    normMatrixAntr=[[normProdAntr[i],normLibAntr[i]] for i in range(len(matriceAntr))]
    normMatrixTest=[[normProdTest[i],normLibTest[i]] for i in range(len(matriceTest))]
    return normMatrixAntr,normMatrixTest


def plot3Ddata(x1Train, x2Train, yTrain, x1Model = None, x2Model = None, yModel = None, x1Test = None, x2Test = None, yTest = None, title = None):

    ax = plt.axes(projection = '3d')
    if (x1Train):
        plt.plot(x1Train, x2Train, yTrain, c = 'r', marker = 'o', label = 'train data')
    if (x1Model):
        plt.plot(x1Model, x2Model, yModel, c = 'b', marker = '_', label = 'learnt model')
    if (x1Test):
        plt.plot(x1Test, x2Test, yTest, c = 'g', marker = '^', label = 'test data')
    plt.title(title)
    ax.set_xlabel("capita")
    ax.set_ylabel("freedom")
    ax.set_zlabel("happiness")
    plt.legend()
    plt.show()

def numericalReprez(feature1,feature2,reg):
    noOfPoints = 100
    xref1 = []
    val = min(feature1)
    step1 = (max(feature1) - min(feature1)) / noOfPoints
    for _ in range(1, noOfPoints):
        for _ in range(1, noOfPoints):
            xref1.append(val)
        val += step1

    xref2 = []
    val = min(feature2)
    step2 = (max(feature2) - min(feature2)) / noOfPoints
    for _ in range(1, noOfPoints):
        aux = val
        for _ in range(1, noOfPoints):
            xref2.append(aux)
            aux += step2
    yref = reg.predict(zip(xref1,xref2))
    return xref1,xref2,yref



#date antrenament
matrice,outputs=citire()



#date test
matriceTeste,realOutputTeste=nrTeste(matrice,outputs)

#date antrenament normalizte
normMatrAntr,normMatrTest=normMatrix(matrice,matriceTeste)

normOutputAntr,normRealOutputTest=normalizareData(outputs,realOutputTeste)

reg=MySGDRegression()

reg.fit(normMatrAntr,normOutputAntr)

computedTestOutputs = reg.predict(normMatrTest)

feature1train=[normMatrAntr[i][0] for i in range(len(normMatrAntr))]
feature2train=[normMatrAntr[i][1] for i in range(len(normMatrAntr))]

feature1test=[normMatrTest[i][0] for i in range(len(normMatrTest))]
feature2test=[normMatrTest[i][1] for i in range(len(normMatrTest))]


print("feature1train")
print(feature1train)
print("feature2train")
print(feature2train)
print("feature1test")
print(feature1test)
print("feature2test")
print(feature2test)


xref1,xref2,yref=numericalReprez(feature1test,feature2test,reg)

plot3Ddata(feature1train, feature2train,normOutputAntr, xref1, xref2, yref, feature1test, feature2test, computedTestOutputs, 'train data and the learnt model')
#plot3Ddata(feature1train, feature2train,normOutput, xref1, xref2, yref, [], [], [], 'train data and the learnt model')
#plot3Ddata([], [],[], xref1, xref2, yref, feature1test, feature2test, computedTestOutputs, 'train data and the learnt model')


error = 0.0
for t1, t2 in zip(computedTestOutputs, normRealOutputTest):
    error += (t1 - t2) ** 2
error = error / len(normRealOutputTest)
print('prediction error (manual): ', error)

from sklearn.metrics import mean_squared_error

error = mean_squared_error(normRealOutputTest, computedTestOutputs)
print('prediction error (tool):   ', error)


print("Sfarsit")





# print(inputTestareGradLib)
# print(inputTestareProdBrut)



# print(rezultat)
# fig = plt.figure()
# ax = plt.axes(projection='3d')
# for i in range(0,len(inputsProdBrut)):
#     plt.plot([outputs[i]],[inputsProdBrut[i]],[inputsGradLib[i]],'ro')
# for i in range(0,len(inputTestareGradLib)):
#     predict=rezultat[0][0]+rezultat[1][0]*inputTestareProdBrut[i]+rezultat[2][0]*inputTestareGradLib[i]
#     plt.plot([predict],inputTestareProdBrut[i],inputTestareGradLib[i],'b^')
#
# y1=rezultat[0][0]
# y2=predict=rezultat[0][0]+rezultat[1][0]*max_prod+rezultat[2][0]*max_lib
# plt.plot([y1,y2],[0,max_prod],[0,max_lib])
#
#
# plt.show()


#[[2.546076701607169], [2.3557110577500624], [1.8735928857661637]]