import random


def loadData(fileName):
    data = []
    dataLable = []
    outputs=[]
    with open(fileName) as file:
        reader=file.readlines()

        for row in reader:
            l=row.split(",")
            lable=l[-1][0:-1]
            l=l[:2]
            if not lable in dataLable:

                dataLable.append(lable)

            data.append(l)
            outputs.append(lable)
    print(dataLable)
    print(data)
    print(outputs)
    return data,outputs,dataLable
    # selectedVariableGradLib = dataNames.index(inputVariableGradLib)
    # inputsGradLib = [float(data[i][selectedVariableGradLib]) for i in range(len(data))]
    #
    # selectedVariableProdBrut = dataNames.index(inputVariaProdIntBrut)
    # inputsProdBrut = [float(data[i][selectedVariableProdBrut]) for i in range(len(data))]
    #
    # selectedOutput = dataNames.index(outputVariabName)
    # outputs = [float(data[i][selectedOutput]) for i in range(len(data))]
    #
    # matrice=creareMatrice(inputsProdBrut,inputsGradLib)
    # return matrice, outputs

def nrTeste(matrice,outputs):
    matriceTeste=[]
    outputsTeste=[]
    nrT=0.2*len(matrice)

    for _ in range(int(nrT)):
        ra=random.randrange(len(matrice)-1)
        #print(ra)
        matriceTeste.append(matrice[ra])
        outputsTeste.append(outputs[ra])
        matrice.pop(ra)
        outputs.pop(ra)
    return matriceTeste,outputsTeste





