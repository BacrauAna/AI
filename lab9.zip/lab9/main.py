from citireFisier import *
from regresion import *

def listCoef(reg,input, matrClassOut):
    matrCoef=[]
    print("input",input)
    for i in range(len(matrClassOut)):
        l=reg.fit(input,matrClassOut[i])
        matrCoef.append(l)
    return matrCoef


def predictOut(matrCompTest,lable):
    outFinal=[]
    for i in range(len(matrCompTest[0])):
        maxim=0
        linie=-1
        for j in range(len(matrCompTest)):
            if float(matrCompTest[j][i])>float(maxim):
                maxim=float(matrCompTest[j][i])
                linie=j
        outFinal.append(lable[linie])
    return outFinal

def predictTestOut(reg, coef, inpTest,lable):
    matrCompTest=[]
    for i in range(len(coef)):
        a=reg.predict(inpTest,coef[i])
        matrCompTest.append(a)
    return predictOut(matrCompTest,lable)


def calculareaTranspusei(matrice):
    matriceTranspusa=[]
    for i in range(len(matrice[0])):
        a=[matrice[j][i] for j in range(len(matrice))]
        matriceTranspusa.append(a)
    return matriceTranspusa


def yForClass(out,lable):
    matrReturn=[]
    for i in range(len(lable)):
        a=[1 if out[j]==lable[i] else 0 for j in range(len(out))]
        #print(a)
        matrReturn.append(a)
    return matrReturn


def normalizareData(inputA,inputT):
    inputAntr=[float(inputA[i]) for i in range(len(inputA))]
    inputTest = [float(inputT[i]) for i in range(len(inputT))]
    medie = sum(inputAntr) / len(inputAntr)
    devStandard = (1 / len(inputAntr) * sum([(inp - medie) ** 2 for inp in inputAntr])) ** 0.5
    normValAntr = [(inp - medie) / devStandard for inp in inputAntr]
    normValTest = [(inp - medie) / devStandard for inp in inputTest]
    return normValAntr,normValTest

def normMatrix(matriceAntr,matriceTest):
    #normMatrixAntr=[]
    #normMatrixAntr=[]
    normALinie=[]
    normTLinie=[]
    for i in range(len(matriceAntr[0])):
        colAntr=[matriceAntr[j][i] for j in range(len(matriceAntr))]
        colTest=[matriceTest[j][i] for j in range(len(matriceTest))]
        normColAntr,normColTest=normalizareData(colAntr,colTest)
        normALinie.append(normColAntr)
        normTLinie.append(normColTest)
    normMatrixAntr=calculareaTranspusei(normALinie)
    normMatrixTest=calculareaTranspusei(normTLinie)
    return normMatrixAntr,normMatrixTest

#date antr
inputs,outputs,lable=loadData("iris.data")

#date test
inpTest,outTest=nrTeste(inputs,outputs)

print("outputTest",outTest)

#normalizare date
normInputAntr,normInputTest=normMatrix(inputs,inpTest)

matrClassOut=yForClass(outputs,lable)

print("\n\n\n\n\n")
print(matrClassOut)
print("\n\n\n\n\n")

reg=MySGDRegression()




coef=listCoef(reg,normInputAntr,matrClassOut)



print("coef")
print(coef)
print("a printat coef")



outCompTest=predictTestOut(reg,coef,normInputTest,lable)

error = 0.0
for t1, t2 in zip(outCompTest, outTest):
    if (t1 != t2):
        error += 1
error = error / len(outTest)
print("classification error (manual): ", error)

from sklearn.metrics import accuracy_score
error = 1 - accuracy_score(outTest, outCompTest)
print("classification error (tool): ", error)

print(outCompTest)