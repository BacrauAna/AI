# import matplotlib.pyplot as plt
# import matplotlib.image as
import random
import numpy as np
import matplotlib.pyplot as plt
from sklearn import neural_network
from sklearn import linear_model
from PIL import Image
# im = Image.open("20200306_162023_DSC_7921.jpg")
# pix = im.load()
# print(im.size)  # Get the width and hight of the image for iterating over
# print(pix[1,1])
# im.show()


def calculareaTranspusei(matrice):
    matriceTranspusa=[]
    for i in range(len(matrice[0])):
        a=[matrice[j][i] for j in range(len(matrice))]
        matriceTranspusa.append(a)
    return matriceTranspusa


def normalizareData(inputA,inputT,i):
    # print("i=",i)
    # if i==97:
    #     print("antr")
    #     print(inputA)
    #     print("test")
    #     print(inputT)
    inputAntr=[float(inputA[i]) for i in range(len(inputA))]
    inputTest = [float(inputT[i]) for i in range(len(inputT))]
    medie = sum(inputAntr) / len(inputAntr)
    devStandard = (1 / len(inputAntr) * sum([(inp - medie) ** 2 for inp in inputAntr])) ** 0.5
    # print("medie=",medie)
    # print("devStandard=",devStandard)
    if devStandard==0:
        normValAntr = [(inp - medie) for inp in inputAntr]
        normValTest = [(inp - medie)  for inp in inputTest]
    else:
        normValAntr = [(inp - medie) / devStandard for inp in inputAntr]
        normValTest = [(inp - medie) / devStandard for inp in inputTest]
    return normValAntr,normValTest

def normMatrix(matriceAntr,matriceTest):
    #normMatrixAntr=[]
    #normMatrixAntr=[]
    normALinie=[]
    normTLinie=[]
    # print("antr")
    # print(len(matriceAntr[0]))
    # print("test")
    # print(len(matriceTest[0]))
    for i in range(len(matriceAntr[0])):
        colAntr=[matriceAntr[j][i] for j in range(len(matriceAntr))]
        colTest=[matriceTest[j][i] for j in range(len(matriceTest))]
        normColAntr,normColTest=normalizareData(colAntr,colTest,i)
        normALinie.append(normColAntr)
        normTLinie.append(normColTest)
    normMatrixAntr=calculareaTranspusei(normALinie)
    normMatrixTest=calculareaTranspusei(normTLinie)
    return normMatrixAntr,normMatrixTest


def normalisation(trainData, testData):
    from sklearn.preprocessing import StandardScaler
    scaler = StandardScaler()
    if not isinstance(trainData[0], list):
        # encode each sample into a list
        trainData = [[d] for d in trainData]
        testData = [[d] for d in testData]

        scaler.fit(trainData)  # fit only on training data
        normalisedTrainData = scaler.transform(trainData)  # apply same transformation to train data
        normalisedTestData = scaler.transform(testData)  # apply same transformation to test data

        # decode from list to raw values
        normalisedTrainData = [el[0] for el in normalisedTrainData]
        normalisedTestData = [el[0] for el in normalisedTestData]
    else:
        scaler.fit(trainData)  # fit only on training data
        normalisedTrainData = scaler.transform(trainData)  # apply same transformation to train data
        normalisedTestData = scaler.transform(testData)  # apply same transformation to test data
    return normalisedTrainData, normalisedTestData

def training(classifier, trainInputs, trainOutputs):
    # step4: training the classifier
    # identify (by training) the classification model
    classifier.fit(trainInputs, trainOutputs)

def classification(classifier, testInputs):
    # step5: testing (predict the labels for new inputs)
    # makes predictions for test data
    computedTestOutputs = classifier.predict(testInputs)

    return computedTestOutputs


def nrTeste(matrice,outputs):
    matriceTeste=[]
    outputsTeste=[]
    nrT=0.2*len(matrice)

    for _ in range(int(nrT)):
        ra=random.randrange(len(matrice)-1)
        #print(ra)
        matriceTeste.append(matrice[ra])
        outputsTeste.append(outputs[ra])
        matrice.pop(ra)
        outputs.pop(ra)
    return matriceTeste,outputsTeste

def calculValRGB(x):
    return 256*256*x[0]+256*x[1]+x[2]

def linear(im):
    pix = im.load()
    x = []
    for line in range(im.size[0]):

        for col in range(im.size[1]):
            x.append(calculValRGB(pix[line,col]))
            # print(pix[line,col])

    return x

def outData(fileOut):
    output = []
    with open(fileOut) as file:
        lines = file.readlines()
        for i in range(0,100):
            output.append(lines[i][:-1])
    return output


def inputsData(fileIn):
    file = fileIn
    input=[]
    for i in range(0,100):

        file_name=str(i)
        while len(file_name)<4:
            file_name="0"+file_name
        im = Image.open(file+file_name+".jpg")

        input.append(linear(im))
    return input

def putRandVal(inp,out):
    ra=random.sample(range(0,len(inp)),len(inp))
    print(ra)
    inpR=[]
    outR=[]
    for i in ra:
        inpR.append(inp[int(i)])
        outR.append(out[int(i)])
    return inpR,outR

def citire():
    inputFaraFiltru=inputsData("fruit\\fruit_")
    inputFiltru=inputsData("sepia\\Untitled Export\\fruit_")
    outFaraFiltru=outData("Output.txt")
    outFiltru=outData("OutSep.txt")
    inputFaraFiltruTest,outFaraFiltruTest=nrTeste(inputFaraFiltru,outFaraFiltru)
    inputFiltruTest,outFiltruTest=nrTeste(inputFiltru,outFiltru)

    input=inputFaraFiltru+inputFiltru
    inputTest=inputFaraFiltruTest+inputFiltruTest
    out=outFaraFiltru+outFiltru
    outTest=outFaraFiltruTest+outFiltruTest

    return input,inputTest,out,outTest

def plotConfusionMatrix(cm, classNames, title):
    from sklearn.metrics import confusion_matrix
    import itertools
    print("cls=",len(classNames))
    print("cm=",cm)
    classes = classNames
    plt.figure()
    plt.imshow(cm, interpolation = 'nearest', cmap = 'Blues')
    plt.title('Confusion Matrix ' + title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    text_format = 'd'
    thresh = cm.max() / 2.
    for row, column in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(column, row, format(cm[row, column], text_format),
                horizontalalignment = 'center',
                color = 'white' if cm[row, column] > thresh else 'black')

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()

    plt.show()

def evalMultiClass(realLabels, computedLabels, labelNames):
    from sklearn.metrics import confusion_matrix
    print("lungime lable=",len(lable))
    confMatrix = confusion_matrix(realLabels, computedLabels)
    acc = sum([confMatrix[i][i] for i in range(len(labelNames))]) / len(realLabels)
    precision = {}
    recall = {}
    for i in range(len(labelNames)):
        precision[labelNames[i]] = confMatrix[i][i] / sum([confMatrix[j][i] for j in range(len(labelNames))])
        recall[labelNames[i]] = confMatrix[i][i] / sum([confMatrix[i][j] for j in range(len(labelNames))])
    return acc, precision, recall, confMatrix

inputAntr,inputTest,outAntr,outTest=citire()

# inputAntr,outAntr=putRandVal(inputAntr,outAntr)
# inputTest,outTest=putRandVal(inputTest,outTest)



# print(inputAntr[97])

# normInpAntr,normInpTest=normMatrix(inputAntr,inputTest)
normInpAntr,normInpTest=normalisation(inputAntr,inputTest)


classifier = neural_network.MLPClassifier(hidden_layer_sizes=(5, ), activation='relu', max_iter=100, solver='adam', verbose=10, random_state=1, learning_rate_init=0.1)
lable=["Fara","Filtru"]


training(classifier,normInpAntr, outAntr)
predictedLabels = classification(classifier, normInpTest)
acc, prec, recall, cm = evalMultiClass(outTest, predictedLabels, lable)

print('acc: ', acc)
print('precision: ', prec)
print('recall: ', recall)

print("ceva")

plotConfusionMatrix(cm, lable, "digit classification")
